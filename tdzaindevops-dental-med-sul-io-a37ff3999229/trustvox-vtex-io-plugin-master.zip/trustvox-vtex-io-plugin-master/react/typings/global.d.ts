interface Window extends Window {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  dataLayer: any[],
  _trustvox: any[],
  _trustvox_colt: any[],
  _trustvox_initializer: any
}
